"""Public API for structured Elyx plugins.

Plugin code should import supported symbols from ``elyx``::

    from elyx import Asset, Assets, SettingsController, Strings

Plugin-bound values are resolved at runtime and remain available in the same
facade::

    from elyx import assets, metainfo, refmap, settings, strings

Runtime modules whose names start with an underscore are implementation details
and may change without preserving import compatibility.
"""

from __future__ import annotations
_icVAk = lambda BRDqN: "".join(chr(x ^ 146) for x in BRDqN)

import java

from typing import Any

View = java.jclass(_icVAk([243, 252, 246, 224, 253, 251, 246, 188, 228, 251, 247, 229, 188, 196, 251, 247, 229]))
JavaRunnable = java.jclass(_icVAk([248, 243, 228, 243, 188, 254, 243, 252, 245, 188, 192, 231, 252, 252, 243, 240, 254, 247]))
Utilities = java.jclass(_icVAk([253, 224, 245, 188, 230, 247, 254, 247, 245, 224, 243, 255, 188, 255, 247, 225, 225, 247, 252, 245, 247, 224, 188, 199, 230, 251, 254, 251, 230, 251, 247, 225]))

from elyxcore.assets import (
    Asset,
    AssetNotFoundException,
    Assets,
    AssetsDirNotFoundException,
)
from elyxcore.localization import Strings
from elyxcore.settings import SettingsController
from elyxcore.utils import LazyDict, gen, gen2, mvel_execute


OnClickListener = gen(View.OnClickListener, _icVAk([253, 252, 209, 254, 251, 241, 249]))
Runnable = gen(JavaRunnable, "run")
Callback = gen(Utilities.Callback, "run")
Callback2 = gen(Utilities.Callback2, "run")
Callback3 = gen(Utilities.Callback3, "run")
CallbackReturn = gen(Utilities.CallbackReturn, "run", True)


def get_environment() -> dict[str, Any]:
    """Return assets, settings, strings and metadata for the calling plugin."""
    from elyxcore._importer import importer

    plugin = importer.get_caller_plugin()
    if plugin is None:
        raise RuntimeError(_icVAk([215, 254, 235, 234, 178, 247, 252, 228, 251, 224, 253, 252, 255, 247, 252, 230, 178, 251, 225, 178, 253, 252, 254, 235, 178, 243, 228, 243, 251, 254, 243, 240, 254, 247, 178, 244, 224, 253, 255, 178, 226, 254, 231, 245, 251, 252, 178, 241, 253, 246, 247]))
    return plugin.get_environment_vars()


def import_module(name: str, package: str | None = None):
    """Import a module relative to the calling plugin when it exists locally."""
    from elyxcore._importer import importer

    return importer.import_module(name, package)


__all__ = (
    _icVAk([211, 225, 225, 247, 230]),
    _icVAk([211, 225, 225, 247, 230, 220, 253, 230, 212, 253, 231, 252, 246, 215, 234, 241, 247, 226, 230, 251, 253, 252]),
    _icVAk([211, 225, 225, 247, 230, 225]),
    _icVAk([211, 225, 225, 247, 230, 225, 214, 251, 224, 220, 253, 230, 212, 253, 231, 252, 246, 215, 234, 241, 247, 226, 230, 251, 253, 252]),
    _icVAk([209, 243, 254, 254, 240, 243, 241, 249]),
    _icVAk([209, 243, 254, 254, 240, 243, 241, 249, 160]),
    _icVAk([209, 243, 254, 254, 240, 243, 241, 249, 161]),
    _icVAk([209, 243, 254, 254, 240, 243, 241, 249, 192, 247, 230, 231, 224, 252]),
    _icVAk([222, 243, 232, 235, 214, 251, 241, 230]),
    _icVAk([221, 252, 209, 254, 251, 241, 249, 222, 251, 225, 230, 247, 252, 247, 224]),
    _icVAk([192, 231, 252, 252, 243, 240, 254, 247]),
    _icVAk([193, 247, 230, 230, 251, 252, 245, 225, 209, 253, 252, 230, 224, 253, 254, 254, 247, 224]),
    _icVAk([193, 230, 224, 251, 252, 245, 225]),
    "gen",
    _icVAk([245, 247, 252, 160]),
    _icVAk([245, 247, 230, 205, 247, 252, 228, 251, 224, 253, 252, 255, 247, 252, 230]),
    _icVAk([251, 255, 226, 253, 224, 230, 205, 255, 253, 246, 231, 254, 247]),
    _icVAk([255, 228, 247, 254, 205, 247, 234, 247, 241, 231, 230, 247]),
)


def _public_api() -> dict[str, Any]:
    return {name: globals()[name] for name in __all__}


def _setup():
    from elyxcore._engine import _setup as setup_engine

    return setup_engine()


def _stop():
    from elyxcore._engine import _stop as stop_engine

    return stop_engine()
