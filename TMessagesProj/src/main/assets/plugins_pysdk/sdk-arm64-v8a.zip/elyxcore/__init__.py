"""Public API for structured Elyx plugins.

Plugin code should import supported symbols from ``elyx``::

    from elyx import Asset, Assets, SettingsController, Strings

Plugin-bound values are resolved at runtime and remain available in the same
facade::

    from elyx import assets, metainfo, refmap, settings, strings

Runtime modules whose names start with an underscore are implementation details
and may change without preserving import compatibility.
"""

from __future__ import annotations
_StX = lambda dhX: "".join(chr(x ^ 43) for x in dhX)

import java

from typing import Any

View = java.jclass(_StX([74, 69, 79, 89, 68, 66, 79, 5, 93, 66, 78, 92, 5, 125, 66, 78, 92]))
JavaRunnable = java.jclass(_StX([65, 74, 93, 74, 5, 71, 74, 69, 76, 5, 121, 94, 69, 69, 74, 73, 71, 78]))
Utilities = java.jclass(_StX([68, 89, 76, 5, 95, 78, 71, 78, 76, 89, 74, 70, 5, 70, 78, 88, 88, 78, 69, 76, 78, 89, 5, 126, 95, 66, 71, 66, 95, 66, 78, 88]))

from elyxcore.assets import (
    Asset,
    AssetNotFoundException,
    Assets,
    AssetsDirNotFoundException,
)
from elyxcore.localization import Strings
from elyxcore.settings import SettingsController
from elyxcore.utils import LazyDict, gen, gen2, mvel_execute


OnClickListener = gen(View.OnClickListener, _StX([68, 69, 104, 71, 66, 72, 64]))
Runnable = gen(JavaRunnable, "run")
Callback = gen(Utilities.Callback, "run")
Callback2 = gen(Utilities.Callback2, "run")
Callback3 = gen(Utilities.Callback3, "run")
CallbackReturn = gen(Utilities.CallbackReturn, "run", True)


def get_environment() -> dict[str, Any]:
    """Return assets, settings, strings and metadata for the calling plugin."""
    from elyxcore._importer import importer

    plugin = importer.get_caller_plugin()
    if plugin is None:
        raise RuntimeError(_StX([110, 71, 82, 83, 11, 78, 69, 93, 66, 89, 68, 69, 70, 78, 69, 95, 11, 66, 88, 11, 68, 69, 71, 82, 11, 74, 93, 74, 66, 71, 74, 73, 71, 78, 11, 77, 89, 68, 70, 11, 91, 71, 94, 76, 66, 69, 11, 72, 68, 79, 78]))
    return plugin.get_environment_vars()


def import_module(name: str, package: str | None = None):
    """Import a module relative to the calling plugin when it exists locally."""
    from elyxcore._importer import importer

    return importer.import_module(name, package)


__all__ = (
    _StX([106, 88, 88, 78, 95]),
    _StX([106, 88, 88, 78, 95, 101, 68, 95, 109, 68, 94, 69, 79, 110, 83, 72, 78, 91, 95, 66, 68, 69]),
    _StX([106, 88, 88, 78, 95, 88]),
    _StX([106, 88, 88, 78, 95, 88, 111, 66, 89, 101, 68, 95, 109, 68, 94, 69, 79, 110, 83, 72, 78, 91, 95, 66, 68, 69]),
    _StX([104, 74, 71, 71, 73, 74, 72, 64]),
    _StX([104, 74, 71, 71, 73, 74, 72, 64, 25]),
    _StX([104, 74, 71, 71, 73, 74, 72, 64, 24]),
    _StX([104, 74, 71, 71, 73, 74, 72, 64, 121, 78, 95, 94, 89, 69]),
    _StX([103, 74, 81, 82, 111, 66, 72, 95]),
    _StX([100, 69, 104, 71, 66, 72, 64, 103, 66, 88, 95, 78, 69, 78, 89]),
    _StX([121, 94, 69, 69, 74, 73, 71, 78]),
    _StX([120, 78, 95, 95, 66, 69, 76, 88, 104, 68, 69, 95, 89, 68, 71, 71, 78, 89]),
    _StX([120, 95, 89, 66, 69, 76, 88]),
    "gen",
    _StX([76, 78, 69, 25]),
    _StX([76, 78, 95, 116, 78, 69, 93, 66, 89, 68, 69, 70, 78, 69, 95]),
    _StX([66, 70, 91, 68, 89, 95, 116, 70, 68, 79, 94, 71, 78]),
    _StX([70, 93, 78, 71, 116, 78, 83, 78, 72, 94, 95, 78]),
)


def _public_api() -> dict[str, Any]:
    return {name: globals()[name] for name in __all__}


def _setup():
    from elyxcore._engine import _setup as setup_engine

    return setup_engine()


def _stop():
    from elyxcore._engine import _stop as stop_engine

    return stop_engine()
