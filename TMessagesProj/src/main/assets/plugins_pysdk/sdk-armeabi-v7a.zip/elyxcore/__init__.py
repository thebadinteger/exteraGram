"""Public API for structured Elyx plugins.

Plugin code should import supported symbols from ``elyx``::

    from elyx import Asset, Assets, SettingsController, Strings

Plugin-bound values are resolved at runtime and remain available in the same
facade::

    from elyx import assets, metainfo, refmap, settings, strings

Runtime modules whose names start with an underscore are implementation details
and may change without preserving import compatibility.
"""

from __future__ import annotations
_ATy = lambda pevH: "".join(chr(x ^ 133) for x in pevH)

import java

from typing import Any

View = java.jclass(_ATy([228, 235, 225, 247, 234, 236, 225, 171, 243, 236, 224, 242, 171, 211, 236, 224, 242]))
JavaRunnable = java.jclass(_ATy([239, 228, 243, 228, 171, 233, 228, 235, 226, 171, 215, 240, 235, 235, 228, 231, 233, 224]))
Utilities = java.jclass(_ATy([234, 247, 226, 171, 241, 224, 233, 224, 226, 247, 228, 232, 171, 232, 224, 246, 246, 224, 235, 226, 224, 247, 171, 208, 241, 236, 233, 236, 241, 236, 224, 246]))

from elyxcore.assets import (
    Asset,
    AssetNotFoundException,
    Assets,
    AssetsDirNotFoundException,
)
from elyxcore.localization import Strings
from elyxcore.settings import SettingsController
from elyxcore.utils import LazyDict, gen, gen2, mvel_execute


OnClickListener = gen(View.OnClickListener, _ATy([234, 235, 198, 233, 236, 230, 238]))
Runnable = gen(JavaRunnable, "run")
Callback = gen(Utilities.Callback, "run")
Callback2 = gen(Utilities.Callback2, "run")
Callback3 = gen(Utilities.Callback3, "run")
CallbackReturn = gen(Utilities.CallbackReturn, "run", True)


def get_environment() -> dict[str, Any]:
    """Return assets, settings, strings and metadata for the calling plugin."""
    from elyxcore._importer import importer

    plugin = importer.get_caller_plugin()
    if plugin is None:
        raise RuntimeError(_ATy([192, 233, 252, 253, 165, 224, 235, 243, 236, 247, 234, 235, 232, 224, 235, 241, 165, 236, 246, 165, 234, 235, 233, 252, 165, 228, 243, 228, 236, 233, 228, 231, 233, 224, 165, 227, 247, 234, 232, 165, 245, 233, 240, 226, 236, 235, 165, 230, 234, 225, 224]))
    return plugin.get_environment_vars()


def import_module(name: str, package: str | None = None):
    """Import a module relative to the calling plugin when it exists locally."""
    from elyxcore._importer import importer

    return importer.import_module(name, package)


__all__ = (
    _ATy([196, 246, 246, 224, 241]),
    _ATy([196, 246, 246, 224, 241, 203, 234, 241, 195, 234, 240, 235, 225, 192, 253, 230, 224, 245, 241, 236, 234, 235]),
    _ATy([196, 246, 246, 224, 241, 246]),
    _ATy([196, 246, 246, 224, 241, 246, 193, 236, 247, 203, 234, 241, 195, 234, 240, 235, 225, 192, 253, 230, 224, 245, 241, 236, 234, 235]),
    _ATy([198, 228, 233, 233, 231, 228, 230, 238]),
    _ATy([198, 228, 233, 233, 231, 228, 230, 238, 183]),
    _ATy([198, 228, 233, 233, 231, 228, 230, 238, 182]),
    _ATy([198, 228, 233, 233, 231, 228, 230, 238, 215, 224, 241, 240, 247, 235]),
    _ATy([201, 228, 255, 252, 193, 236, 230, 241]),
    _ATy([202, 235, 198, 233, 236, 230, 238, 201, 236, 246, 241, 224, 235, 224, 247]),
    _ATy([215, 240, 235, 235, 228, 231, 233, 224]),
    _ATy([214, 224, 241, 241, 236, 235, 226, 246, 198, 234, 235, 241, 247, 234, 233, 233, 224, 247]),
    _ATy([214, 241, 247, 236, 235, 226, 246]),
    "gen",
    _ATy([226, 224, 235, 183]),
    _ATy([226, 224, 241, 218, 224, 235, 243, 236, 247, 234, 235, 232, 224, 235, 241]),
    _ATy([236, 232, 245, 234, 247, 241, 218, 232, 234, 225, 240, 233, 224]),
    _ATy([232, 243, 224, 233, 218, 224, 253, 224, 230, 240, 241, 224]),
)


def _public_api() -> dict[str, Any]:
    return {name: globals()[name] for name in __all__}


def _setup():
    from elyxcore._engine import _setup as setup_engine

    return setup_engine()


def _stop():
    from elyxcore._engine import _stop as stop_engine

    return stop_engine()
