"""Public API for structured Elyx plugins.

Plugin code should import supported symbols from ``elyx``::

    from elyx import Asset, Assets, SettingsController, Strings

Plugin-bound values are resolved at runtime and remain available in the same
facade::

    from elyx import assets, metainfo, refmap, settings, strings

Runtime modules whose names start with an underscore are implementation details
and may change without preserving import compatibility.
"""

from __future__ import annotations
_SlGL = lambda oTJxNc: "".join(chr(x ^ 36) for x in oTJxNc)

import java

from typing import Any

View = java.jclass(_SlGL([69, 74, 64, 86, 75, 77, 64, 10, 82, 77, 65, 83, 10, 114, 77, 65, 83]))
JavaRunnable = java.jclass(_SlGL([78, 69, 82, 69, 10, 72, 69, 74, 67, 10, 118, 81, 74, 74, 69, 70, 72, 65]))
Utilities = java.jclass(_SlGL([75, 86, 67, 10, 80, 65, 72, 65, 67, 86, 69, 73, 10, 73, 65, 87, 87, 65, 74, 67, 65, 86, 10, 113, 80, 77, 72, 77, 80, 77, 65, 87]))

from elyxcore.assets import (
    Asset,
    AssetNotFoundException,
    Assets,
    AssetsDirNotFoundException,
)
from elyxcore.localization import Strings
from elyxcore.settings import SettingsController
from elyxcore.utils import LazyDict, gen, gen2, mvel_execute


OnClickListener = gen(View.OnClickListener, _SlGL([75, 74, 103, 72, 77, 71, 79]))
Runnable = gen(JavaRunnable, "run")
Callback = gen(Utilities.Callback, "run")
Callback2 = gen(Utilities.Callback2, "run")
Callback3 = gen(Utilities.Callback3, "run")
CallbackReturn = gen(Utilities.CallbackReturn, "run", True)


def get_environment() -> dict[str, Any]:
    """Return assets, settings, strings and metadata for the calling plugin."""
    from elyxcore._importer import importer

    plugin = importer.get_caller_plugin()
    if plugin is None:
        raise RuntimeError(_SlGL([97, 72, 93, 92, 4, 65, 74, 82, 77, 86, 75, 74, 73, 65, 74, 80, 4, 77, 87, 4, 75, 74, 72, 93, 4, 69, 82, 69, 77, 72, 69, 70, 72, 65, 4, 66, 86, 75, 73, 4, 84, 72, 81, 67, 77, 74, 4, 71, 75, 64, 65]))
    return plugin.get_environment_vars()


def import_module(name: str, package: str | None = None):
    """Import a module relative to the calling plugin when it exists locally."""
    from elyxcore._importer import importer

    return importer.import_module(name, package)


__all__ = (
    _SlGL([101, 87, 87, 65, 80]),
    _SlGL([101, 87, 87, 65, 80, 106, 75, 80, 98, 75, 81, 74, 64, 97, 92, 71, 65, 84, 80, 77, 75, 74]),
    _SlGL([101, 87, 87, 65, 80, 87]),
    _SlGL([101, 87, 87, 65, 80, 87, 96, 77, 86, 106, 75, 80, 98, 75, 81, 74, 64, 97, 92, 71, 65, 84, 80, 77, 75, 74]),
    _SlGL([103, 69, 72, 72, 70, 69, 71, 79]),
    _SlGL([103, 69, 72, 72, 70, 69, 71, 79, 22]),
    _SlGL([103, 69, 72, 72, 70, 69, 71, 79, 23]),
    _SlGL([103, 69, 72, 72, 70, 69, 71, 79, 118, 65, 80, 81, 86, 74]),
    _SlGL([104, 69, 94, 93, 96, 77, 71, 80]),
    _SlGL([107, 74, 103, 72, 77, 71, 79, 104, 77, 87, 80, 65, 74, 65, 86]),
    _SlGL([118, 81, 74, 74, 69, 70, 72, 65]),
    _SlGL([119, 65, 80, 80, 77, 74, 67, 87, 103, 75, 74, 80, 86, 75, 72, 72, 65, 86]),
    _SlGL([119, 80, 86, 77, 74, 67, 87]),
    "gen",
    _SlGL([67, 65, 74, 22]),
    _SlGL([67, 65, 80, 123, 65, 74, 82, 77, 86, 75, 74, 73, 65, 74, 80]),
    _SlGL([77, 73, 84, 75, 86, 80, 123, 73, 75, 64, 81, 72, 65]),
    _SlGL([73, 82, 65, 72, 123, 65, 92, 65, 71, 81, 80, 65]),
)


def _public_api() -> dict[str, Any]:
    return {name: globals()[name] for name in __all__}


def _setup():
    from elyxcore._engine import _setup as setup_engine

    return setup_engine()


def _stop():
    from elyxcore._engine import _stop as stop_engine

    return stop_engine()
